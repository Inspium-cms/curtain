<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?php echo $__env->yieldContent('title', 'Curtains & Blinds | Dashboard'); ?></title>
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="" />
    <?php echo $__env->yieldContent('seo'); ?>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/CSS/menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/CSS/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/CSS/mutliselectInput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/CSS/seachableInput.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div class="container-fluid p-0">
        <div class="d-flex justify-content-start">
            <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="w-100">
                <?php echo $__env->make('admin.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        

        <!-- Footer -->
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- / Footer -->
       <!-- delete modal start -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body">
                    <p>Are your sure you want to delete?</p>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="secondary-btn me-2 addBtn" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="primary-btn addBtn">Yes</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- delete modal end -->
  
<!-- success Modal -->
<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="thankuModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <i class="bi bi-check-circle" style="color: #181818; font-size: 40px;"></i>
                <h6 id="successMessage">Your Message</h6>
            </div>
        </div>
    </div>
</div>


<!-- error Modal -->
<div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="thankuModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <i class="bi bi-x-circle" style="color: #ff3f3f; font-size: 40px;"></i>
                <h6 id="errorMessage">Your Message</h6>
            </div>
        </div>
    </div>
</div>

<!-- Check for success message and show modal -->
<?php if(session('success')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Set the message
            document.getElementById('successMessage').textContent = "<?php echo e(session('success')); ?>";

            // Show the modal
            let successModal = new bootstrap.Modal(document.getElementById('successModal'));
            successModal.show();
        });
    </script>
<?php endif; ?>

<!-- Check for error message and show modal -->
<?php if(session('error')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Set the error message
            document.getElementById('errorMessage').textContent = "<?php echo e(session('error')); ?>";

            // Show the modal
            let errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
            errorModal.show();
        });
    </script>
<?php endif; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.js"
        integrity="sha512-+k1pnlgt4F1H8L7t3z95o3/KO+o78INEcXTbnoJQ/F2VqDVhWoaiVml/OEHv9HsVgxUaVW+IbiZPUJQfF/YxZw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
    <!-- datatabel -->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('admin/JS/datatable.js')); ?>"></script>

    <!-- menu script -->
    <script src="<?php echo e(asset('admin/JS/sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/JS/menu.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/JS/franchise.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/JS/multiselectInput.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/JS/searchableselect.js')); ?>"></script>
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/example-app1/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>