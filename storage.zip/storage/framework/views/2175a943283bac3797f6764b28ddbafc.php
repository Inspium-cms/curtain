<?php $__env->startSection('title', 'Customert Appointment List'); ?>

<?php $__env->startSection('content'); ?>
<div class="dataOverviewSection mt-3">
    <div class="section-title">
        <h6 class="fw-bold m-0">All Appointments <span class="fw-normal text-muted">(<?php echo e(count($pendingAppointments)+count($assignedAppointments)); ?>)</span></h6>
        
    </div>

    <div class="dataOverview mt-3">
        <div>
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pills-confirm-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-confirm" type="button" role="tab"
                        aria-controls="pills-confirm" aria-selected="true">Appointment Booked <span
                            class="fw-normal small">(<?php echo e(count($pendingAppointments)); ?>)</span></button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-pending-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-pending" type="button" role="tab"
                        aria-controls="pills-pending" aria-selected="false">Franchise Assigned<span
                            class="fw-normal small">(<?php echo e(count($assignedAppointments)); ?>)</span></button>
                </li>
                

            </ul>
        </div>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-confirm" role="tabpanel"
                aria-labelledby="pills-confirm-tab" tabindex="0">
                <div class="table-responsive">
                    <table class="table" id="projectsTable">
                        <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Address</th>
                                <th>Pincode</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Country</th>
                                <th>Assign</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pendingAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx=>$appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($idx+1); ?></td>
                                    <td><?php echo e($appointment->name); ?></td>
                                    <td><?php echo e($appointment->email); ?></td>
                                    <td><?php echo e($appointment->mobile); ?></td>
                                    <td><?php echo e($appointment->address); ?></td>
                                    <td><?php echo e($appointment->pincode); ?></td>
                                    <td><?php echo e($appointment->city); ?></td>
                                    <td><?php echo e($appointment->state); ?></td>
                                    <td><?php echo e($appointment->country); ?></td>
                                    <td>
                                        
                                        <div class="dropdown">
                                            <i class="bi bi-three-dots-vertical" type="button"
                                                data-bs-toggle="dropdown" aria-expanded="false"></i>
                                            <ul class="dropdown-menu">
                                                
                                                <li>
                                                    <a href="javascript:" class="dropdown-item small approve-franchise-btn" data-franchise-id="<?php echo e($appointment->id); ?>" onclick="confirmAssign('<?php echo e($appointment->id); ?>')">Assign Franchise</a>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="tab-pane fade" id="pills-pending" role="tabpanel"
                aria-labelledby="pills-pending-tab" tabindex="0">
                <div class="table-responsive">
                    <table class="table" id="pendingFranchise">
                        <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Address</th>
                            <th>Pincode</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Country</th>
                            <th>Franchise</th>
                            <th>Appointment Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $assignedAppointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx=>$franchise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                
                                <td><?php echo e($idx+1); ?></td>
                                <td><?php echo e($franchise->name); ?></td>
                                <td><?php echo e($franchise->email); ?></td>
                                <td><?php echo e($franchise->mobile); ?></td>
                                <td><?php echo e($franchise->address); ?></td>
                                <td><?php echo e($franchise->pincode); ?></td>
                                <td><?php echo e($franchise->city); ?></td>
                                <td><?php echo e($franchise->state); ?></td>
                                <td><?php echo e($franchise->country); ?></td>
                                <td><span class="badge badge-active"><?php echo e($franchise->franchise_name); ?></span></td>
                                <td><?php echo e($franchise->appointment_date); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
            <div class="tab-pane fade" id="pills-rejected" role="tabpanel"
                aria-labelledby="pills-rejected-tab" tabindex="0">
                <div class="table-responsive">
                    <table class="table" id="projectsTable">
                        <thead>
                            <tr>
                                <th style="border-top-left-radius: 6px; border-bottom-left-radius: 6px;"
                                    scope="col">S/N</th>
                                <th scope="col">Name</th>
                                <th scope="col">Individual/Company</th>
                                <th scope="col">Company Name</th>
                                <th scope="col">Number</th>
                                <th scope="col">Pincode</th>
                                <th scope="col">City</th>
                                <th scope="col">Status</th>
                                <th style="border-top-right-radius: 6px; border-bottom-right-radius: 6px;"
                                    scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr>
                                <td>01</td>
                                <td>Ramesh Kumar</td>
                                <td>Campany</td>
                                <td>abc pvt ltd</td>
                                <td>+91 9876543211</td>
                                <td>110059</td>
                                <td>New Delhi</td>
                                <td><span class="badge badge-inactive">Rejected</span></td>
                                <td>
                                    <div class="dropdown">
                                        <i class="bi bi-three-dots-vertical" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false"></i>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item small" href="#">View</a></li>
                                            <li><a class="dropdown-item small" href="#">Confirm</a>
                                            </li>
                                            <li><a class="dropdown-item small" href="#"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal">Reject</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>01</td>
                                <td>Ramesh Kumar</td>
                                <td>Campany</td>
                                <td>abc pvt ltd</td>
                                <td>+91 9876543211</td>
                                <td>110059</td>
                                <td>New Delhi</td>
                                <td><span class="badge badge-inactive">Rejected</span></td>
                                <td>
                                    <div class="dropdown">
                                        <i class="bi bi-three-dots-vertical" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false"></i>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item small" href="#">View</a></li>
                                            <li><a class="dropdown-item small" href="#">Confirm</a>
                                            </li>
                                            <li><a class="dropdown-item small" href="#"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal">Reject</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>01</td>
                                <td>Ramesh Kumar</td>
                                <td>Campany</td>
                                <td>abc pvt ltd</td>
                                <td>+91 9876543211</td>
                                <td>110059</td>
                                <td>New Delhi</td>
                                <td><span class="badge badge-inactive">Rejected</span></td>
                                <td>
                                    <div class="dropdown">
                                        <i class="bi bi-three-dots-vertical" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false"></i>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item small" href="#">View</a></li>
                                            <li><a class="dropdown-item small" href="#">Confirm</a>
                                            </li>
                                            <li><a class="dropdown-item small" href="#"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal">Reject</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>01</td>
                                <td>Ramesh Kumar</td>
                                <td>Campany</td>
                                <td>abc pvt ltd</td>
                                <td>+91 9876543211</td>
                                <td>110059</td>
                                <td>New Delhi</td>
                                <td><span class="badge badge-inactive">Rejected</span></td>
                                <td>
                                    <div class="dropdown">
                                        <i class="bi bi-three-dots-vertical" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false"></i>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item small" href="#">View</a></li>
                                            <li><a class="dropdown-item small" href="#">Confirm</a>
                                            </li>
                                            <li><a class="dropdown-item small" href="#"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal">Reject</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>01</td>
                                <td>Ramesh Kumar</td>
                                <td>Campany</td>
                                <td>abc pvt ltd</td>
                                <td>+91 9876543211</td>
                                <td>110059</td>
                                <td>New Delhi</td>
                                <td><span class="badge badge-inactive">Rejected</span></td>
                                <td>
                                    <div class="dropdown">
                                        <i class="bi bi-three-dots-vertical" type="button"
                                            data-bs-toggle="dropdown" aria-expanded="false"></i>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item small" href="#">View</a></li>
                                            <li><a class="dropdown-item small" href="#">Confirm</a>
                                            </li>
                                            <li><a class="dropdown-item small" href="#"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal">Reject</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Approval Modal -->
<div class="modal fade" id="assignAppointmentModal" tabindex="-1" aria-labelledby="approveFranchiseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form action="<?php echo e(route('appointments.assign')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="approveFranchiseModalLabel">Approve Franchise</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="appointmentId" name="appointment_id">
                    <div class="mb-3">
                        <label for="franchise" class="form-label">Select Franchise<span class="requried">*</span></label>
                        <select id="franchise" name="franchise_id" class="form-select w-100" required>
                            <option value="">Select Franchise</option>
                            <?php $__currentLoopData = $franchises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $franchise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($franchise->id); ?>"><?php echo e($franchise->company_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="date" class="form-label">Appointment Date</label>
                        <input type="date" name="dateFilter" id="dateFilter" placeholder="Filter by date" value="<?php echo e(request('dateFilter')); ?>"
                    class="form-control me-3 w-100">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="secondary-btn" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="primary-btn">Assign</button>
                </div>
            </form>
        </div>
    </div>
</div>
 
<!-- Add Franchise Modal End -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function confirmAssign(appointmentId) {
    // Open modal and set appointment ID
    $('#assignAppointmentModal').modal('show');
    $('#appointmentId').val(appointmentId);
}

    // $(document).ready(function() {
        $('#pincode').on('blur', function() {
            var pincode = $(this).val();
            if (pincode) {
                $.ajax({
                    url: '/get-location',
                    method: 'POST',
                    data: {
                        pincode: pincode,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        $('#country').val(response.country);
                        $('#state').val(response.state);
                        $('#city').val(response.city);
                    },
                    error: function() {
                        alert('Location not found!');
                    }
                });
            }
        });
    // });
</script>

    <script>
        $(document).ready(function(){
            $(".dt-responsive").dataTable({
              responsive: true,
              columnDefs: [
                  { responsivePriority: 1, targets: 0 },
                  { responsivePriority: 2, targets: -1 }
              ]
            });
            $(".dt-responsive1").dataTable({
              responsive: true,
              columnDefs: [
                  { responsivePriority: 1, targets: 0 },
                  { responsivePriority: 2, targets: -1 }
              ]
            });
        });
    </script>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/example-app1/resources/views/admin/appointments.blade.php ENDPATH**/ ?>