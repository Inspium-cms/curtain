<footer>
  <div class="footer">
      <p class="m-0">Copyright © 2023 All rights reserved.</p>
  </div>
</footer><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/example-app1/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>